// ReBook - campus book exchange
// Data is saved in the browser using localStorage (no backend needed)

let items = JSON.parse(localStorage.getItem("rebookItems")) || [];

// get elements from the page
const addForm = document.getElementById("addForm");
const itemList = document.getElementById("itemList");
const searchBox = document.getElementById("search");
const filterBranch = document.getElementById("filterBranch");
const onlyFree = document.getElementById("onlyFree");

// save items to localStorage
function saveItems() {
  localStorage.setItem("rebookItems", JSON.stringify(items));
}

// update the 3 boxes at the top
function updateStats() {
  let freeCount = 0;
  let saved = 0;

  for (let i = 0; i < items.length; i++) {
    if (items[i].price === 0) {
      freeCount++;
    }
    // money saved = original price - price we are selling at
    saved = saved + (items[i].originalPrice - items[i].price);
  }

  document.getElementById("totalItems").textContent = items.length;
  document.getElementById("freeItems").textContent = freeCount;
  document.getElementById("moneySaved").textContent = "Rs. " + saved;
}

// show the items on the page (after search and filter)
function showItems() {
  const searchText = searchBox.value.toLowerCase();
  const branch = filterBranch.value;
  const freeOnly = onlyFree.checked;

  itemList.innerHTML = "";
  let shown = 0;

  for (let i = 0; i < items.length; i++) {
    const item = items[i];

    // check the filters
    if (!item.title.toLowerCase().includes(searchText)) continue;
    if (branch !== "All" && item.branch !== branch) continue;
    if (freeOnly && item.price !== 0) continue;

    shown++;

    const div = document.createElement("div");
    div.className = "item";
    if (item.price === 0) {
      div.classList.add("free");
    }

    // textContent is used so that nobody can add html in the form
    const title = document.createElement("h4");
    title.textContent = item.title;

    const info = document.createElement("p");
    info.textContent = item.type + " | " + item.branch;

    const price = document.createElement("p");
    price.className = "price";
    if (item.price === 0) {
      price.textContent = "FREE (donated)";
    } else {
      price.textContent = "Rs. " + item.price + " (original Rs. " + item.originalPrice + ")";
    }

    const owner = document.createElement("p");
    owner.textContent = "Listed by: " + item.owner;

    const contact = document.createElement("p");
    contact.textContent = "Contact: " + item.contact;

    const del = document.createElement("button");
    del.className = "delete-btn";
    del.textContent = "Mark as taken";
    del.onclick = function () {
      deleteItem(item.id);
    };

    div.append(title, info, price, owner, contact, del);
    itemList.appendChild(div);
  }

  if (shown === 0) {
    itemList.innerHTML = "<p>No items found. Add one using the form above.</p>";
  }
}

// remove an item
function deleteItem(id) {
  items = items.filter(function (item) {
    return item.id !== id;
  });
  saveItems();
  updateStats();
  showItems();
}

// when the form is submitted
addForm.addEventListener("submit", function (e) {
  e.preventDefault();

  const originalPrice = Number(document.getElementById("originalPrice").value);
  const price = Number(document.getElementById("price").value);

  if (price > originalPrice) {
    alert("Your price cannot be more than the original price.");
    return;
  }

  const newItem = {
    id: Date.now(),
    title: document.getElementById("title").value.trim(),
    owner: document.getElementById("owner").value.trim(),
    contact: document.getElementById("contact").value.trim(),
    branch: document.getElementById("branch").value,
    type: document.getElementById("type").value,
    originalPrice: originalPrice,
    price: price
  };

  items.unshift(newItem); // add at the start
  saveItems();
  updateStats();
  showItems();
  addForm.reset();
});

// run showItems again when the user searches or changes filters
searchBox.addEventListener("input", showItems);
filterBranch.addEventListener("change", showItems);
onlyFree.addEventListener("change", showItems);

// first load
updateStats();
showItems();
